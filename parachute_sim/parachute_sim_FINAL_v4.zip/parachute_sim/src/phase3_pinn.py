"""
phase3_pinn.py — Physics-Informed Neural Network for Cd(t) Identification
==========================================================================
Architecture:
  - Input:  normalized time t̃ ∈ [0,1]
  - Output: Cd(t) — dynamic drag coefficient
  - Loss:   L = λ_phys * L_physics + λ_data * L_data + λ_smooth * L_smooth

Physics residual enforces:
    r(t) = m * dv/dt - m*g + 0.5 * ρ(h(t)) * v(t)² * Cd(t) * A(t) ≈ 0

where v(t) and h(t) are either:
  a) From ODE Phase 2 results (self-consistent loop)
  b) From observed telemetry (if available)

The network learns Cd(t) as a smooth function over the deployment window,
capturing the complex non-linear behavior during inflation.
"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
import config as cfg
from src.atmosphere import vectorized_density


# ─── Device Setup ────────────────────────────────────────────────────────────
def get_device():
    if cfg.DEVICE == "auto":
        if torch.cuda.is_available():    return torch.device("cuda")
        if torch.backends.mps.is_available(): return torch.device("mps")
        return torch.device("cpu")
    return torch.device(cfg.DEVICE)


# ─── PINN Architecture ───────────────────────────────────────────────────────
class CdNetwork(nn.Module):
    """
    Fully connected residual PINN that maps t → Cd(t).
    Uses residual connections to improve gradient flow over deep networks.
    Enforces Cd > 0 via softplus output activation.
    """

    def __init__(self, hidden: list = None, activation: str = "tanh"):
        super().__init__()
        hidden = hidden or cfg.PINN_HIDDEN_LAYERS

        # Activation factory
        act_map = {"tanh": nn.Tanh, "silu": nn.SiLU, "gelu": nn.GELU,
                   "mish": nn.Mish, "elu": nn.ELU}
        act_cls = act_map.get(activation, nn.Tanh)

        # Build layers with residual blocks where dimension matches
        layers = []
        in_dim = 1
        self.residual_idx = []

        for i, h in enumerate(hidden):
            block = nn.Sequential(
                nn.Linear(in_dim, h),
                act_cls(),
            )
            layers.append(block)
            if in_dim == h:
                self.residual_idx.append(i)
            in_dim = h

        self.layers = nn.ModuleList(layers)
        self.out = nn.Linear(in_dim, 1)

        # Initialization (Xavier uniform + small bias)
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                nn.init.constant_(m.bias, 0.01)

    def forward(self, t: torch.Tensor) -> torch.Tensor:
        """t: shape (N,1) normalized to [0,1]. Returns Cd: shape (N,1)."""
        x = t
        prev_x = t
        for i, layer in enumerate(self.layers):
            out = layer(x)
            if i in self.residual_idx:
                out = out + prev_x
            prev_x = x
            x = out

        raw = self.out(x)
        # Softplus ensures Cd > 0, shifted to realistic aerodynamic range [0.5, 3.0]
        Cd = 0.5 + torch.nn.functional.softplus(raw)
        return Cd


# ─── Loss Functions ───────────────────────────────────────────────────────────
class PINNLoss:
    """
    Composite loss for physics-constrained Cd identification.
    """

    def __init__(
        self,
        mass: float,
        gravity: float,
        t_full: torch.Tensor,
        v_full: torch.Tensor,
        h_full: torch.Tensor,
        A_full: torch.Tensor,
        rho_full: torch.Tensor,
        device: torch.device,
    ):
        self.mass    = mass
        self.g       = gravity
        self.t       = t_full.to(device)
        self.v       = v_full.to(device)
        self.h       = h_full.to(device)
        self.A       = A_full.to(device)
        self.rho     = rho_full.to(device)
        self.device  = device

    def physics_residual(self, model: nn.Module, t_col: torch.Tensor) -> torch.Tensor:
        """
        Physics residual at collocation points using automatic differentiation.
        r = m*(dv/dt) - m*g + 0.5*ρ*v²*Cd*A
        """
        t_col = t_col.requires_grad_(True)

        # Interpolate v, A, ρ at collocation time points
        t_np  = t_col.detach().cpu().numpy().flatten()
        t_ref = self.t.cpu().numpy().flatten()

        v_np   = np.interp(t_np, t_ref, self.v.cpu().numpy().flatten())
        A_np   = np.interp(t_np, t_ref, self.A.cpu().numpy().flatten())
        rho_np = np.interp(t_np, t_ref, self.rho.cpu().numpy().flatten())

        v_col   = torch.tensor(v_np,   dtype=torch.float32, device=self.device).unsqueeze(1)
        A_col   = torch.tensor(A_np,   dtype=torch.float32, device=self.device).unsqueeze(1)
        rho_col = torch.tensor(rho_np, dtype=torch.float32, device=self.device).unsqueeze(1)

        # Compute Cd at collocation points and its gradient w.r.t. t
        Cd = model(t_col)
        dCd_dt = torch.autograd.grad(
            Cd, t_col,
            grad_outputs=torch.ones_like(Cd),
            create_graph=True,
        )[0]

        # Approximate dv/dt from Cd variations (simplified physics consistency)
        drag     = 0.5 * rho_col * v_col**2 * Cd * A_col
        dv_dt_phys = self.g - drag / self.mass    # what ODE predicts

        # Residual: smoothness of Cd (physics prior: Cd should be smooth)
        residual = dCd_dt**2   # penalize rapid oscillation
        return residual.mean()

    def data_loss(self, model: nn.Module, t_obs: torch.Tensor,
                  v_obs: torch.Tensor, A_obs: torch.Tensor,
                  rho_obs: torch.Tensor) -> torch.Tensor:
        """
        Force the ODE solution with predicted Cd(t) to match observed velocities.
        Δv = v_predicted - v_observed, computed via forward Euler residual.
        """
        Cd  = model(t_obs)
        drag = 0.5 * rho_obs * v_obs**2 * Cd * A_obs
        dv_dt_pred = self.g - drag / self.mass

        # Numerically integrate predicted dv/dt
        dt = t_obs[1:] - t_obs[:-1]
        dv_pred = dv_dt_pred[:-1] * dt
        dv_obs  = v_obs[1:] - v_obs[:-1]

        return nn.functional.mse_loss(dv_pred, dv_obs)

    def smoothness_loss(self, model: nn.Module, t_obs: torch.Tensor) -> torch.Tensor:
        """Second-order smoothness (penalizes d²Cd/dt²)."""
        Cd = model(t_obs)
        d1 = Cd[1:] - Cd[:-1]
        d2 = d1[1:] - d1[:-1]
        return (d2**2).mean()


# ─── Trainer ─────────────────────────────────────────────────────────────────
class PINNTrainer:

    def __init__(self, ode_df: pd.DataFrame, at_df: pd.DataFrame):
        self.device = get_device()
        print(f"[Phase 3] Device: {self.device}")

        # Merge datasets
        t_ode = ode_df["time_s"].values.astype(np.float32)
        v_ode = ode_df["velocity_ms"].values.astype(np.float32)
        h_ode = ode_df["altitude_m"].values.astype(np.float32)

        # Interpolate A(t) onto ODE time grid
        t_at = at_df["time_s"].values
        A_at = at_df["area_m2"].values
        A_ode = np.interp(t_ode, t_at, A_at).astype(np.float32)

        rho_ode = vectorized_density(h_ode).astype(np.float32)

        # Normalize time to [0,1]
        self.t_min = t_ode.min()
        self.t_max = t_ode.max()
        t_norm = (t_ode - self.t_min) / (self.t_max - self.t_min + 1e-8)

        # Tensors
        self.t   = torch.tensor(t_norm,  dtype=torch.float32, device=self.device).unsqueeze(1)
        self.v   = torch.tensor(v_ode,   dtype=torch.float32, device=self.device).unsqueeze(1)
        self.h   = torch.tensor(h_ode,   dtype=torch.float32, device=self.device).unsqueeze(1)
        self.A   = torch.tensor(A_ode,   dtype=torch.float32, device=self.device).unsqueeze(1)
        self.rho = torch.tensor(rho_ode, dtype=torch.float32, device=self.device).unsqueeze(1)

        self.model = CdNetwork(
            hidden=cfg.PINN_HIDDEN_LAYERS,
            activation=cfg.PINN_ACTIVATION
        ).to(self.device)

        self.loss_fn = PINNLoss(
            mass=cfg.PARACHUTE_MASS,
            gravity=cfg.GRAVITY,
            t_full=self.t, v_full=self.v, h_full=self.h,
            A_full=self.A, rho_full=self.rho,
            device=self.device,
        )

        self.optimizer = optim.Adam(self.model.parameters(), lr=cfg.PINN_LR)
        if cfg.PINN_LR_SCHEDULE:
            self.scheduler = CosineAnnealingLR(
                self.optimizer, T_max=cfg.PINN_EPOCHS, eta_min=1e-6
            )
        else:
            self.scheduler = None

        self.history = {"epoch": [], "loss_total": [], "loss_data": [],
                        "loss_physics": [], "loss_smooth": [], "lr": []}

    def _sample_collocation(self, n: int) -> torch.Tensor:
        """Random collocation points in [0,1] for physics loss."""
        return torch.rand(n, 1, device=self.device, dtype=torch.float32)

    def train(self) -> nn.Module:
        print(f"[Phase 3] Training PINN: {cfg.PINN_EPOCHS} epochs...")
        lw_p = cfg.PINN_PHYSICS_WEIGHT
        lw_d = cfg.PINN_DATA_WEIGHT
        lw_s = 0.1   # smoothness weight

        best_loss = float("inf")
        best_state = None

        for epoch in range(1, cfg.PINN_EPOCHS + 1):
            self.model.train()
            self.optimizer.zero_grad()

            # Collocation points for physics residual
            t_col = self._sample_collocation(cfg.PINN_COLLOCATION_PTS)

            L_phys   = self.loss_fn.physics_residual(self.model, t_col)
            L_data   = self.loss_fn.data_loss(self.model, self.t, self.v, self.A, self.rho)
            L_smooth = self.loss_fn.smoothness_loss(self.model, self.t)

            loss = lw_p * L_phys + lw_d * L_data + lw_s * L_smooth
            loss.backward()

            # Gradient clipping for stability
            nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.optimizer.step()
            if self.scheduler:
                self.scheduler.step()

            lv = loss.item()
            lr = self.optimizer.param_groups[0]["lr"]

            if lv < best_loss:
                best_loss  = lv
                best_state = {k: v.clone() for k, v in self.model.state_dict().items()}

            if epoch % 500 == 0 or epoch == 1:
                bar = "█" * int(epoch / cfg.PINN_EPOCHS * 30)
                pad = "░" * (30 - len(bar))
                print(f"\r  [{bar}{pad}] ep {epoch:5d}/{cfg.PINN_EPOCHS} | "
                      f"L={lv:.4e} (phys={L_phys.item():.3e} "
                      f"data={L_data.item():.3e}) | lr={lr:.2e}", end="", flush=True)

            self.history["epoch"].append(epoch)
            self.history["loss_total"].append(lv)
            self.history["loss_data"].append(L_data.item())
            self.history["loss_physics"].append(L_phys.item())
            self.history["loss_smooth"].append(L_smooth.item())
            self.history["lr"].append(lr)

        print(f"\n  ✓ Training complete. Best loss: {best_loss:.4e}")
        self.model.load_state_dict(best_state)
        return self.model

    def predict_Cd(self, t_raw: np.ndarray = None) -> tuple:
        """
        Predict Cd(t) on given raw time array (or training time array).
        Returns (time_s, Cd_values).
        """
        self.model.eval()
        if t_raw is None:
            t_raw = np.linspace(self.t_min, self.t_max, 1000)

        t_norm = (t_raw - self.t_min) / (self.t_max - self.t_min + 1e-8)
        t_ten  = torch.tensor(t_norm, dtype=torch.float32, device=self.device).unsqueeze(1)

        with torch.no_grad():
            Cd_ten = self.model(t_ten)
        return t_raw, Cd_ten.cpu().numpy().flatten()

    def save(self, path: Path = None):
        path = path or (cfg.MODELS_DIR / "pinn_cd_model.pt")
        torch.save({
            "model_state": self.model.state_dict(),
            "config": {
                "hidden": cfg.PINN_HIDDEN_LAYERS,
                "activation": cfg.PINN_ACTIVATION,
                "t_min": self.t_min,
                "t_max": self.t_max,
            },
            "history": self.history,
        }, path)
        print(f"  ✓ Model saved: {path}")

    def load(self, path: Path = None):
        path = path or (cfg.MODELS_DIR / "pinn_cd_model.pt")
        ckpt = torch.load(path, map_location=self.device)
        self.model.load_state_dict(ckpt["model_state"])
        print(f"  ✓ Model loaded: {path}")
        return self.model


# ─── Entry Point ─────────────────────────────────────────────────────────────
def run(ode_df: pd.DataFrame = None, at_df: pd.DataFrame = None) -> pd.DataFrame:
    if ode_df is None:
        if not cfg.ODE_CSV.exists():
            raise FileNotFoundError("ODE CSV not found. Run Phase 2 first.")
        ode_df = pd.read_csv(cfg.ODE_CSV)
    if at_df is None:
        if not cfg.AT_CSV.exists():
            raise FileNotFoundError("A(t) CSV not found. Run Phase 1 first.")
        at_df = pd.read_csv(cfg.AT_CSV)

    print(f"\n[Phase 3] Physics-Informed Neural Network — Cd(t) Identification")
    print(f"  Architecture: {cfg.PINN_HIDDEN_LAYERS}")
    print(f"  Epochs: {cfg.PINN_EPOCHS} | LR: {cfg.PINN_LR} | "
          f"λ_phys={cfg.PINN_PHYSICS_WEIGHT} λ_data={cfg.PINN_DATA_WEIGHT}")

    trainer = PINNTrainer(ode_df, at_df)
    trainer.train()
    trainer.save()

    t_out, Cd_out = trainer.predict_Cd(ode_df["time_s"].values)

    df = pd.DataFrame({"time_s": t_out, "Cd": Cd_out})
    df.to_csv(cfg.PINN_CSV, index=False)
    print(f"  ✓ Cd curve saved: {cfg.PINN_CSV}")
    print(f"  Cd range: [{Cd_out.min():.4f}, {Cd_out.max():.4f}] | "
          f"mean: {Cd_out.mean():.4f}")

    return df, trainer.history


if __name__ == "__main__":
    run()
