"""
phase2_ode.py — Physics ODE Simulator
======================================
Solves the parachute inflation dynamics ODE:

    m * dv/dt = m*g - 0.5 * ρ(h) * v² * Cd * A(t)
    dh/dt     = -v   (descending → positive v means downward)

Integrates using scipy's RK45 (or configurable method) with:
  - ISA standard atmosphere for ρ(h)
  - Interpolated A(t) from Phase 1 CSV
  - Jerk, drag force, and dynamic pressure as output channels
"""

import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from scipy.interpolate import interp1d, UnivariateSpline
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
import config as cfg
from src.atmosphere import density


# ─── Inflation Models ────────────────────────────────────────────────────────
class InflationModel:
    """
    Wraps A(t) as a smooth callable.
    Supports: CSV interpolation, generalized logistic fit, polynomial fit.
    """

    def __init__(self, df: pd.DataFrame, mode: str = "csv_interpolated"):
        self.mode = mode
        self.t_data = df["time_s"].values.astype(float)
        self.A_data = df["area_m2"].values.astype(float)
        self.A_max  = self.A_data.max()
        self.t_max  = self.t_data.max()

        if mode == "csv_interpolated":
            self._fn = interp1d(
                self.t_data, self.A_data,
                kind="cubic", bounds_error=False,
                fill_value=(self.A_data[0], self.A_max)
            )
        elif mode == "generalized_logistic":
            self._fn = self._fit_generalized_logistic()
        elif mode == "polynomial":
            self._fn = self._fit_polynomial()
        else:
            raise ValueError(f"Unknown inflation model: {mode}")

    def _fit_generalized_logistic(self):
        from scipy.optimize import curve_fit

        def logistic(t, k, t0, n, A_inf):
            return A_inf / (1 + np.exp(-k * (t - t0))) ** (1 / n)

        p0 = [2.0, self.t_max * 0.4, 1.5, self.A_max]
        bounds = ([0.1, 0, 0.1, 0.1 * self.A_max],
                  [20, self.t_max, 10, 1.5 * self.A_max])
        try:
            popt, _ = curve_fit(logistic, self.t_data, self.A_data,
                                 p0=p0, bounds=bounds, maxfev=5000)
            print(f"  Logistic fit: k={popt[0]:.3f}, t0={popt[1]:.3f}s, "
                  f"n={popt[2]:.3f}, A_inf={popt[3]:.2f}m²")
            return lambda t: np.clip(logistic(t, *popt), 0, 1.5 * self.A_max)
        except Exception as e:
            print(f"  Logistic fit failed ({e}), falling back to spline.")
            return interp1d(self.t_data, self.A_data, kind="cubic",
                            bounds_error=False, fill_value=(0, self.A_max))

    def _fit_polynomial(self):
        deg = min(7, len(self.t_data) // 10)
        coeffs = np.polyfit(self.t_data, self.A_data, deg)
        poly = np.poly1d(coeffs)
        return lambda t: np.clip(poly(t), 0, 1.5 * self.A_max)

    def __call__(self, t: float | np.ndarray) -> float | np.ndarray:
        return np.clip(self._fn(t), 0, None)

    def derivative(self, t: float, dt: float = 1e-4) -> float:
        """Numerical derivative dA/dt via central difference."""
        return (self(t + dt) - self(t - dt)) / (2 * dt)


# ─── ODE System ──────────────────────────────────────────────────────────────
class ParachuteODE:
    """
    Encapsulates the 2-state parachute descent ODE:
        state = [v, h]   (velocity [m/s], altitude [m])
    """

    def __init__(
        self,
        At_model: InflationModel,
        mass: float = None,
        Cd: float = None,
    ):
        self.A    = At_model
        self.mass = mass or cfg.PARACHUTE_MASS
        self.Cd   = Cd   or cfg.CD_INITIAL

    def rhs(self, t: float, state: np.ndarray) -> list:
        """Right-hand side of the ODE system."""
        v, h = state
        v = max(v, 0.0)     # velocity cannot be negative (no bounce model)

        rho  = density(h)
        A_t  = self.A(t)
        drag = 0.5 * rho * v**2 * self.Cd * A_t
        buoy = 0.0          # neglected for dense payload

        dv_dt = cfg.GRAVITY - (drag + buoy) / self.mass
        dh_dt = -v          # altitude decreases as vehicle descends

        return [dv_dt, dh_dt]

    def solve(
        self,
        t_span: tuple = None,
        t_eval: np.ndarray = None,
        method: str = None,
    ) -> dict:
        """
        Integrate the ODE over t_span.
        Returns a rich dict of physical quantities.
        """
        t0 = 0.0
        t_end = t_span[1] if t_span else self.A.t_max + 5.0
        if t_eval is None:
            t_eval = np.linspace(t0, t_end, max(2000, int(t_end * 100)))

        y0 = [cfg.INITIAL_VEL, cfg.INITIAL_ALT]

        # Terminal condition: ground impact
        def ground_hit(t, y): return y[1]
        ground_hit.terminal  = True
        ground_hit.direction = -1

        sol = solve_ivp(
            self.rhs,
            t_span=(t0, t_end),
            y0=y0,
            method=method or cfg.ODE_METHOD,
            t_eval=t_eval,
            events=ground_hit,
            rtol=cfg.ODE_RTOL,
            atol=cfg.ODE_ATOL,
            dense_output=True,
        )

        if not sol.success:
            raise RuntimeError(f"ODE solver failed: {sol.message}")

        t  = sol.t
        v  = sol.y[0]
        h  = sol.y[1]
        At = self.A(t)

        rho_arr  = np.array([density(hi) for hi in h])
        drag_arr = 0.5 * rho_arr * v**2 * self.Cd * At
        a_arr    = (np.gradient(v, t))                    # acceleration m/s²
        q_arr    = 0.5 * rho_arr * v**2                   # dynamic pressure Pa
        Ma_arr   = v / np.array([342.0] * len(t))         # Mach (sea-level approx)

        # Energy bookkeeping
        KE  = 0.5 * self.mass * v**2
        PE  = self.mass * cfg.GRAVITY * h

        # Snatch load estimation (peak drag force during inflation)
        dA_dt = np.gradient(At, t)
        snatch_force = 0.5 * rho_arr * v**2 * self.Cd * dA_dt

        return {
            "time_s"        : t,
            "velocity_ms"   : v,
            "altitude_m"    : h,
            "area_m2"       : At,
            "acceleration"  : a_arr,
            "drag_force_N"  : drag_arr,
            "dynamic_press" : q_arr,
            "density_kgm3"  : rho_arr,
            "mach"          : Ma_arr,
            "KE_J"          : KE,
            "PE_J"          : PE,
            "snatch_force_N": snatch_force,
        }

    def to_dataframe(self, results: dict) -> pd.DataFrame:
        return pd.DataFrame({k: v for k, v in results.items()
                              if isinstance(v, np.ndarray)})


# ─── Entry Point ─────────────────────────────────────────────────────────────
def run(at_df: pd.DataFrame = None) -> pd.DataFrame:
    if at_df is None:
        if not cfg.AT_CSV.exists():
            raise FileNotFoundError(
                "A(t) CSV not found. Run Phase 1 first, or pass at_df directly."
            )
        at_df = pd.read_csv(cfg.AT_CSV)

    print(f"\n[Phase 2] ODE Simulator")
    print(f"  Mass: {cfg.PARACHUTE_MASS} kg | Cd: {cfg.CD_INITIAL} | "
          f"Alt0: {cfg.INITIAL_ALT} m | V0: {cfg.INITIAL_VEL} m/s")
    print(f"  Inflation model: {cfg.INFLATION_MODEL}")

    At_model = InflationModel(at_df, mode=cfg.INFLATION_MODEL)
    ode      = ParachuteODE(At_model)

    print(f"  Integrating [{cfg.ODE_METHOD}]...")
    results = ode.solve()

    t   = results["time_s"]
    v   = results["velocity_ms"]
    h   = results["altitude_m"]
    drag = results["drag_force_N"]

    terminal_v = v[-1] if h[-1] < 1.0 else None
    print(f"  ✓ Solved {len(t)} points over {t[-1]:.2f}s")
    if terminal_v is not None:
        print(f"  Terminal velocity at ground: {terminal_v:.2f} m/s ({terminal_v*3.6:.1f} km/h)")
    print(f"  Peak drag force: {drag.max():.1f} N | Peak deceleration: {abs(results['acceleration'].min()):.2f} m/s²")

    df = ode.to_dataframe(results)
    df.to_csv(cfg.ODE_CSV, index=False)
    print(f"  ✓ Saved: {cfg.ODE_CSV}")

    return df, At_model


if __name__ == "__main__":
    df, _ = run()
