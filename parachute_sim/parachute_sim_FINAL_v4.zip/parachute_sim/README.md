# AI-Driven Parachute Dynamics & Inflation Modeling System v4.0

> Zero-cost. Zero API keys. 100% local. Industry-grade physics.

## Governing Equation

    m · dv/dt = mg − ½ · ρ(h) · v² · Cd(t) · A(t)

## Quick Start

    pip install numpy scipy pandas matplotlib scikit-learn opencv-python tqdm Pillow

    # Fast run (no torch needed)
    python main.py --synthetic --shock --design --bayes --no-pinn --no-mc

    # Full pipeline
    python main.py --synthetic --full

    # Real video + live wind
    python main.py --video drop_test.mp4 --lat 51.5074 --lon -0.1278

    # Run tests
    pip install pytest && pytest tests/ -v

## Modules

    Phase 1  OpenCV canopy area extraction
    Phase 2  RK45 ODE + ICAO ISA 7-layer atmosphere
    Phase 3  Physics-Informed Neural Network Cd(t)
    Phase 4  8-panel publication dashboard
    Phase 5  Monte Carlo UQ (P5/P50/P95 bands)
    Phase 6  3D wind-drift trajectory + Open-Meteo + KML
    Phase 7  Drogue→Main state machine + MIL-HDBK-1791 snatch loads
    Phase 8  12-state pendulum ODE (Cartesian + Baumgarte stabilisation)

    opening_shock.py    MIL-HDBK-1791 CLA + structural safety factors
    bayes_cd.py         Bayesian MCMC (emcee) / Laplace Cd posterior
    pinn_ensemble.py    Heteroscedastic ensemble epistemic+aleatoric UQ
    design_calc.py      brentq area solver + HTML engineering datasheet
    ingest_telemetry.py GPX / Pixhawk .bin / CSV / JSON / FIT ingestion
    calibrate_cd.py     brentq + bootstrap Cd back-solver
    fetch_wind.py       Open-Meteo live wind profile (free, no key)

## CLI Reference

    --synthetic          Use synthetic A(t) data
    --full               ALL phases + ALL analysis modules
    --video FILE         Real drop-test .mp4
    --phase N            Run single phase (1-8)
    --from-phase / --to-phase
    --no-pinn            Skip Phase 3 (PINN training)
    --no-mc              Skip Phase 5 (Monte Carlo)
    --shock              Opening shock MIL-HDBK-1791
    --bayes              Bayesian Cd estimation
    --ensemble           PINN ensemble uncertainty
    --design             Design calculator
    --ingest FILE        Telemetry ingestion
    --lat/--lon          Open-Meteo live wind
    --target-v N         Design calculator target landing speed (m/s)
    --mass/--alt0/--cd   Physics parameter overrides

## Outputs (23 files)

    dashboard.png               8-panel simulation dashboard
    multistage_dashboard.png    Drogue->Main + snatch load table
    pendulum_dashboard.png      9-panel pendulum + Poincare section
    mc_dashboard.png            Monte Carlo confidence bands
    trajectory_3d.png           3D wind-drift + landing ellipse
    opening_shock.png           MIL-HDBK-1791 force history + SF
    bayes_cd_posterior.png      Bayesian posterior + MCMC chains
    pinn_ensemble.png           Ensemble disagreement heat-map
    design_calc.png             Area solver + performance sweep
    telemetry_ingest.png        Quality report + ground track
    engineering_report.html     Self-contained HTML (all plots embedded)
    design_datasheet.html       Engineering datasheet
    trajectory.kml              Google Earth flight path
    + 10 CSV/JSON data files

## Zero-Cost Stack

    scipy       ODE, optimisation, statistics   BSD
    PyTorch     PINN + ensemble                 BSD
    emcee       MCMC (optional)                 MIT
    OpenCV      Computer vision                 Apache-2
    Open-Meteo  Live wind data                  CC-BY 4.0
    pymavlink   Pixhawk .bin (optional)         LGPL
    gpxpy       GPX track (optional)            Apache-2

Total cost: $0.00
